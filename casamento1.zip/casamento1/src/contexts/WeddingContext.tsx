
import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";

// Interfaces para os tipos de dados
interface Guest {
  id: string;
  name: string;
  email: string;
  phone: string;
  confirmed: boolean;
  numberOfGuests: number;
  message?: string;
  timestamp: Date;
}

interface Note {
  id: string;
  title: string;
  content: string;
  timestamp: Date;
}

interface ExpenseCategory {
  id: string;
  name: string;
  amount: number;
  color: string;
}

interface WeddingEvent {
  id: string;
  title: string;
  time: string;
  location: string;
  description: string;
}

interface GalleryItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail: string;
  description?: string;
  uploadedBy: 'couple' | 'guest';
  guestName?: string;
}

interface WeddingContextType {
  // Dados do casamento
  weddingDate: Date;
  brideAndGroom: { bride: string; groom: string };
  venue: { name: string; address: string; lat: number; lng: number };
  
  // Funções para convidados
  guests: Guest[];
  addGuest: (guest: Omit<Guest, 'id' | 'timestamp'>) => Promise<void>;
  
  // Funções para notas
  notes: Note[];
  addNote: (note: Omit<Note, 'id' | 'timestamp'>) => Promise<void>;
  removeNote: (id: string) => Promise<void>;
  
  // Orçamento
  budget: { total: number; expenses: ExpenseCategory[] };
  updateExpense: (id: string, amount: number) => Promise<void>;
  addExpenseCategory: (category: Omit<ExpenseCategory, 'id'>) => Promise<void>;
  removeExpenseCategory: (id: string) => Promise<void>;
  
  // Eventos
  events: WeddingEvent[];
  
  // Galeria
  galleryItems: GalleryItem[];
  addGalleryItem: (item: Omit<GalleryItem, 'id'>) => Promise<void>;
  
  // Admin
  isAdmin: boolean;
  login: (password: string) => boolean;
  logout: () => void;

  // Loading status
  loading: boolean;
}

const WeddingContext = createContext<WeddingContextType | undefined>(undefined);

export const WeddingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  
  // Estados para os dados
  const [weddingDate, setWeddingDate] = useState<Date>(new Date());
  const [brideAndGroom, setBrideAndGroom] = useState({ bride: '', groom: '' });
  const [venue, setVenue] = useState({
    name: '',
    address: '',
    lat: 0,
    lng: 0
  });
  
  const [guests, setGuests] = useState<Guest[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [budget, setBudget] = useState({
    total: 0,
    expenses: [] as ExpenseCategory[]
  });
  const [events, setEvents] = useState<WeddingEvent[]>([]);
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  
  // Verificar status de admin
  useEffect(() => {
    const storedIsAdmin = localStorage.getItem('wedding_isAdmin');
    if (storedIsAdmin) {
      setIsAdmin(JSON.parse(storedIsAdmin));
    }
  }, []);
  
  // Salvar status de admin no localStorage
  useEffect(() => {
    localStorage.setItem('wedding_isAdmin', JSON.stringify(isAdmin));
  }, [isAdmin]);
  
  // Fetch wedding details
  useEffect(() => {
    const fetchWeddingDetails = async () => {
      try {
        const { data, error } = await supabase
          .from('wedding_details')
          .select('*')
          .single();
        
        if (error) {
          console.error('Error fetching wedding details:', error);
          return;
        }
        
        if (data) {
          setWeddingDate(new Date(data.wedding_date));
          setBrideAndGroom({ bride: data.bride, groom: data.groom });
          setVenue({
            name: data.venue_name,
            address: data.venue_address,
            lat: data.venue_lat || 0,
            lng: data.venue_lng || 0
          });
        }
      } catch (error) {
        console.error('Error in fetchWeddingDetails:', error);
      }
    };
    
    fetchWeddingDetails();
  }, []);
  
  // Fetch guests
  useEffect(() => {
    const fetchGuests = async () => {
      try {
        const { data, error } = await supabase
          .from('guests')
          .select('*')
          .order('created_at', { ascending: false });
        
        if (error) {
          console.error('Error fetching guests:', error);
          return;
        }
        
        if (data) {
          const formattedGuests: Guest[] = data.map(guest => ({
            id: guest.id,
            name: guest.name,
            email: guest.email || '',
            phone: guest.phone || '',
            confirmed: guest.confirmed || false,
            numberOfGuests: guest.number_of_guests || 1,
            message: guest.message,
            timestamp: new Date(guest.created_at)
          }));
          
          setGuests(formattedGuests);
        }
      } catch (error) {
        console.error('Error in fetchGuests:', error);
      }
    };
    
    fetchGuests();
  }, []);
  
  // Fetch notes
  useEffect(() => {
    const fetchNotes = async () => {
      try {
        const { data, error } = await supabase
          .from('notes')
          .select('*')
          .order('created_at', { ascending: false });
        
        if (error) {
          console.error('Error fetching notes:', error);
          return;
        }
        
        if (data) {
          const formattedNotes: Note[] = data.map(note => ({
            id: note.id,
            title: note.title,
            content: note.content || '',
            timestamp: new Date(note.created_at)
          }));
          
          setNotes(formattedNotes);
        }
      } catch (error) {
        console.error('Error in fetchNotes:', error);
      }
    };
    
    fetchNotes();
  }, []);
  
  // Fetch expenses
  useEffect(() => {
    const fetchExpenses = async () => {
      try {
        const { data, error } = await supabase
          .from('expense_categories')
          .select('*')
          .order('name', { ascending: true });
        
        if (error) {
          console.error('Error fetching expenses:', error);
          return;
        }
        
        if (data) {
          const formattedExpenses: ExpenseCategory[] = data.map(expense => ({
            id: expense.id,
            name: expense.name,
            amount: Number(expense.amount) || 0,
            color: expense.color
          }));
          
          const total = formattedExpenses.reduce((sum, expense) => sum + expense.amount, 0);
          
          setBudget({
            total,
            expenses: formattedExpenses
          });
        }
      } catch (error) {
        console.error('Error in fetchExpenses:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchExpenses();
  }, []);
  
  // Fetch events
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const { data, error } = await supabase
          .from('wedding_events')
          .select('*')
          .order('time', { ascending: true });
        
        if (error) {
          console.error('Error fetching events:', error);
          return;
        }
        
        if (data) {
          const formattedEvents: WeddingEvent[] = data.map(event => ({
            id: event.id,
            title: event.title,
            time: event.time,
            location: event.location,
            description: event.description || ''
          }));
          
          setEvents(formattedEvents);
        }
      } catch (error) {
        console.error('Error in fetchEvents:', error);
      }
    };
    
    fetchEvents();
  }, []);
  
  // Fetch gallery items
  useEffect(() => {
    const fetchGalleryItems = async () => {
      try {
        const { data, error } = await supabase
          .from('gallery_items')
          .select('*')
          .order('created_at', { ascending: false });
        
        if (error) {
          console.error('Error fetching gallery items:', error);
          return;
        }
        
        if (data) {
          const formattedGalleryItems: GalleryItem[] = data.map(item => ({
            id: item.id,
            type: item.type as 'image' | 'video',
            url: item.url,
            thumbnail: item.thumbnail,
            description: item.description,
            uploadedBy: item.uploaded_by as 'couple' | 'guest',
            guestName: item.guest_name
          }));
          
          setGalleryItems(formattedGalleryItems);
        }
      } catch (error) {
        console.error('Error in fetchGalleryItems:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchGalleryItems();
  }, []);
  
  // Funções para manipular os dados
  const addGuest = async (guest: Omit<Guest, 'id' | 'timestamp'>) => {
    try {
      const { data, error } = await supabase
        .from('guests')
        .insert([{
          name: guest.name,
          email: guest.email,
          phone: guest.phone,
          confirmed: guest.confirmed,
          number_of_guests: guest.numberOfGuests,
          message: guest.message
        }])
        .select()
        .single();
      
      if (error) {
        throw error;
      }
      
      if (data) {
        const newGuest: Guest = {
          id: data.id,
          name: data.name,
          email: data.email || '',
          phone: data.phone || '',
          confirmed: data.confirmed || false,
          numberOfGuests: data.number_of_guests || 1,
          message: data.message,
          timestamp: new Date(data.created_at)
        };
        
        setGuests(prevGuests => [newGuest, ...prevGuests]);
      }
    } catch (error) {
      console.error('Error in addGuest:', error);
      toast({
        title: "Erro ao adicionar convidado",
        description: "Ocorreu um erro ao adicionar o convidado. Por favor, tente novamente.",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const addNote = async (note: Omit<Note, 'id' | 'timestamp'>) => {
    try {
      const { data, error } = await supabase
        .from('notes')
        .insert([{
          title: note.title,
          content: note.content
        }])
        .select()
        .single();
      
      if (error) {
        throw error;
      }
      
      if (data) {
        const newNote: Note = {
          id: data.id,
          title: data.title,
          content: data.content || '',
          timestamp: new Date(data.created_at)
        };
        
        setNotes(prevNotes => [newNote, ...prevNotes]);
      }
    } catch (error) {
      console.error('Error in addNote:', error);
      toast({
        title: "Erro ao adicionar nota",
        description: "Ocorreu um erro ao adicionar a nota. Por favor, tente novamente.",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const removeNote = async (id: string) => {
    try {
      const { error } = await supabase
        .from('notes')
        .delete()
        .eq('id', id);
      
      if (error) {
        throw error;
      }
      
      setNotes(prevNotes => prevNotes.filter(note => note.id !== id));
    } catch (error) {
      console.error('Error in removeNote:', error);
      toast({
        title: "Erro ao remover nota",
        description: "Ocorreu um erro ao remover a nota. Por favor, tente novamente.",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const updateExpense = async (id: string, amount: number) => {
    try {
      console.log("Updating expense in database:", id, amount);
      // Check if we're updating an existing expense
      const expenseExists = budget.expenses.some(expense => expense.id === id);
      
      if (expenseExists) {
        // Update existing expense
        const { error } = await supabase
          .from('expense_categories')
          .update({ amount })
          .eq('id', id);
        
        if (error) {
          console.error("Supabase update error:", error);
          throw error;
        }
        
        console.log("Database update successful");
        const updatedExpenses = budget.expenses.map(expense => 
          expense.id === id ? { ...expense, amount } : expense
        );
        
        const newTotal = updatedExpenses.reduce((sum, expense) => sum + expense.amount, 0);
        
        setBudget({
          total: newTotal,
          expenses: updatedExpenses
        });
        
        toast({
          title: "Despesa atualizada",
          description: "A despesa foi atualizada com sucesso.",
        });
      } else {
        // This shouldn't happen with the current UI, but we'll handle it just in case
        toast({
          title: "Erro ao atualizar despesa",
          description: "Categoria de despesa não encontrada.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error in updateExpense:', error);
      toast({
        title: "Erro ao atualizar despesa",
        description: "Ocorreu um erro ao atualizar a despesa. Por favor, tente novamente.",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const addExpenseCategory = async (category: Omit<ExpenseCategory, 'id'>) => {
    try {
      console.log("Adding new expense category:", category);
      const { data, error } = await supabase
        .from('expense_categories')
        .insert([{
          name: category.name,
          amount: category.amount,
          color: category.color
        }])
        .select()
        .single();
      
      if (error) {
        console.error("Supabase insert error:", error);
        throw error;
      }
      
      console.log("Database insert successful:", data);
      if (data) {
        const newCategory: ExpenseCategory = {
          id: data.id,
          name: data.name,
          amount: Number(data.amount) || 0,
          color: data.color
        };
        
        const updatedExpenses = [...budget.expenses, newCategory];
        const newTotal = updatedExpenses.reduce((sum, expense) => sum + expense.amount, 0);
        
        setBudget({
          total: newTotal,
          expenses: updatedExpenses
        });
        
        toast({
          title: "Categoria adicionada",
          description: "A categoria de despesa foi adicionada com sucesso.",
        });
      }
    } catch (error) {
      console.error('Error in addExpenseCategory:', error);
      toast({
        title: "Erro ao adicionar categoria",
        description: "Ocorreu um erro ao adicionar a categoria de despesa. Por favor, tente novamente.",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const removeExpenseCategory = async (id: string) => {
    try {
      console.log("Removing expense category:", id);
      const { error } = await supabase
        .from('expense_categories')
        .delete()
        .eq('id', id);
      
      if (error) {
        console.error("Supabase delete error:", error);
        throw error;
      }
      
      console.log("Database delete successful");
      const updatedExpenses = budget.expenses.filter(expense => expense.id !== id);
      const newTotal = updatedExpenses.reduce((sum, expense) => sum + expense.amount, 0);
      
      setBudget({
        total: newTotal,
        expenses: updatedExpenses
      });
      
      toast({
        title: "Categoria removida",
        description: "A categoria de despesa foi removida com sucesso.",
      });
    } catch (error) {
      console.error('Error in removeExpenseCategory:', error);
      toast({
        title: "Erro ao remover categoria",
        description: "Ocorreu um erro ao remover a categoria de despesa. Por favor, tente novamente.",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const addGalleryItem = async (item: Omit<GalleryItem, 'id'>) => {
    try {
      const { data, error } = await supabase
        .from('gallery_items')
        .insert([{
          type: item.type,
          url: item.url,
          thumbnail: item.thumbnail,
          description: item.description,
          uploaded_by: item.uploadedBy,
          guest_name: item.guestName
        }])
        .select()
        .single();
      
      if (error) {
        throw error;
      }
      
      if (data) {
        const newItem: GalleryItem = {
          id: data.id,
          type: data.type as 'image' | 'video',
          url: data.url,
          thumbnail: data.thumbnail,
          description: data.description,
          uploadedBy: data.uploaded_by as 'couple' | 'guest',
          guestName: data.guest_name
        };
        
        setGalleryItems(prevItems => [newItem, ...prevItems]);
      }
    } catch (error) {
      console.error('Error in addGalleryItem:', error);
      toast({
        title: "Erro ao adicionar item na galeria",
        description: "Ocorreu um erro ao adicionar o item na galeria. Por favor, tente novamente.",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const login = (password: string) => {
    // Esta função é apenas para compatibilidade, o login real é feito na página de Login
    if (password === 'admin123') {
      setIsAdmin(true);
      return true;
    }
    return false;
  };
  
  const logout = () => {
    setIsAdmin(false);
    localStorage.removeItem('wedding_isAdmin');
  };
  
  return (
    <WeddingContext.Provider
      value={{
        weddingDate,
        brideAndGroom,
        venue,
        guests,
        addGuest,
        notes,
        addNote,
        removeNote,
        budget,
        updateExpense,
        addExpenseCategory,
        removeExpenseCategory,
        events,
        galleryItems,
        addGalleryItem,
        isAdmin,
        login,
        logout,
        loading
      }}
    >
      {children}
    </WeddingContext.Provider>
  );
};

export const useWedding = () => {
  const context = useContext(WeddingContext);
  if (context === undefined) {
    throw new Error('useWedding must be used within a WeddingProvider');
  }
  return context;
};
