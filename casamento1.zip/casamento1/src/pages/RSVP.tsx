
import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useWedding } from "@/contexts/WeddingContext";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Check, Send } from "lucide-react";

const RSVP = () => {
  const { addGuest } = useWedding();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    numberOfGuests: 1,
    message: "",
    confirmed: true,
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: parseInt(value) || 1 }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      await addGuest(formData);
      
      toast({
        title: "Presença confirmada!",
        description: "Obrigado por confirmar sua presença. Será um prazer receber você!",
      });
      
      setIsSubmitted(true);
    } catch (error) {
      console.error("Erro ao confirmar presença:", error);
      
      toast({
        title: "Erro ao confirmar presença",
        description: "Ocorreu um erro ao confirmar sua presença. Por favor, tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <div className="text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-display font-semibold mb-3">
              Confirmação de Presença
            </h1>
            <p className="text-muted-foreground">
              Estamos ansiosos para celebrar este momento especial com você. Por favor, confirme sua presença.
            </p>
          </div>
          
          <Card className="bg-white shadow-md border-border/50">
            <CardHeader>
              <CardTitle>RSVP</CardTitle>
              <CardDescription>
                Por favor, preencha o formulário abaixo para confirmar sua presença.
              </CardDescription>
            </CardHeader>
            
            {isSubmitted ? (
              <CardContent className="pt-6 text-center">
                <div className="mb-6 flex justify-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                    <Check className="h-8 w-8 text-green-600" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-2">Presença Confirmada!</h3>
                <p className="text-muted-foreground mb-4">
                  Obrigado por confirmar sua presença. Será um prazer receber você em nosso casamento.
                </p>
                <Button 
                  onClick={() => setIsSubmitted(false)}
                  variant="outline"
                >
                  Enviar outra confirmação
                </Button>
              </CardContent>
            ) : (
              <form onSubmit={handleSubmit}>
                <CardContent className="pt-6 space-y-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nome completo</Label>
                      <Input
                        id="name"
                        name="name"
                        placeholder="Digite seu nome completo"
                        value={formData.name}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email">E-mail</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="Digite seu e-mail"
                        value={formData.email}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefone</Label>
                      <Input
                        id="phone"
                        name="phone"
                        placeholder="Digite seu número de telefone"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="numberOfGuests">Número de convidados</Label>
                      <Input
                        id="numberOfGuests"
                        name="numberOfGuests"
                        type="number"
                        min="1"
                        max="5"
                        value={formData.numberOfGuests}
                        onChange={handleNumberChange}
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="message">Mensagem (opcional)</Label>
                    <Textarea
                      id="message"
                      name="message"
                      placeholder="Deixe uma mensagem para os noivos..."
                      value={formData.message}
                      onChange={handleChange}
                      rows={4}
                    />
                  </div>
                </CardContent>
                
                <CardFooter className="flex justify-between">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setFormData((prev) => ({ ...prev, confirmed: false }))}
                    className={!formData.confirmed ? "bg-muted" : ""}
                  >
                    Infelizmente não poderei ir
                  </Button>
                  
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-wedding-purple hover:bg-wedding-purple/90"
                  >
                    {isSubmitting ? (
                      "Enviando..."
                    ) : (
                      <>
                        Confirmar Presença
                        <Send className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </CardFooter>
              </form>
            )}
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default RSVP;
