
import { useRef } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useWedding } from "@/contexts/WeddingContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, MapPin } from "lucide-react";

const Info = () => {
  const { events, venue } = useWedding();
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-display font-semibold mb-3">
              Informações
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
              Tudo o que você precisa saber sobre nosso grande dia.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="text-2xl font-display font-semibold mb-6 flex items-center">
                <Clock className="mr-2 h-5 w-5 text-wedding-purple" />
                Programação
              </h2>
              
              <div className="space-y-6">
                {events.map((event) => (
                  <div key={event.id} className="relative pl-8 before:absolute before:left-0 before:top-0 before:h-full before:w-px before:bg-wedding-lavender">
                    <span className="absolute left-[-8px] top-1 h-4 w-4 rounded-full bg-wedding-purple"></span>
                    <h3 className="text-xl font-semibold mb-1">{event.title}</h3>
                    <p className="text-muted-foreground mb-2">
                      <span className="font-medium">{event.time}</span> • {event.location}
                    </p>
                    <p className="text-sm text-muted-foreground">{event.description}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h2 className="text-2xl font-display font-semibold mb-6 flex items-center">
                <MapPin className="mr-2 h-5 w-5 text-wedding-purple" />
                Localização
              </h2>
              
              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-xl">
                    {venue.name}
                  </CardTitle>
                  <CardDescription>
                    {venue.address}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video w-full rounded-md overflow-hidden bg-muted">
                    <iframe
                      width="100%"
                      height="100%"
                      frameBorder="0"
                      title="Mapa do Local"
                      src={`https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=${encodeURIComponent(venue.address)}`}
                      allowFullScreen
                    ></iframe>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Info;
