
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import HeroSection from "@/components/HeroSection";
import { Link } from "react-router-dom";
import { Calendar, Camera, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWedding } from "@/contexts/WeddingContext";

const Index = () => {
  const { weddingDate, venue } = useWedding();
  
  const features = [
    {
      icon: <Calendar className="h-10 w-10 text-wedding-purple" />,
      title: "RSVP",
      description: "Confirme sua presença em nosso casamento",
      link: "/rsvp",
    },
    {
      icon: <Camera className="h-10 w-10 text-wedding-purple" />,
      title: "Galeria",
      description: "Veja nossos momentos especiais e compartilhe os seus",
      link: "/gallery",
    },
    {
      icon: <MapPin className="h-10 w-10 text-wedding-purple" />,
      title: "Informações",
      description: "Programação completa e localização do evento",
      link: "/info",
    },
  ];
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <HeroSection />
        
        <section className="py-20 bg-wedding-light">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-display font-semibold mb-3">
                Celebre Conosco
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Estamos emocionados em compartilhar este momento especial com nossos amigos e familiares.
                Esperamos sua presença para celebrar o nosso amor.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-lg shadow-md p-6 border border-border/50 hover-lift"
                >
                  <div className="flex flex-col items-center text-center">
                    <div className="p-3 bg-wedding-lavender/20 rounded-full mb-4">
                      {feature.icon}
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground mb-4">{feature.description}</p>
                    <Button variant="link" asChild>
                      <Link to={feature.link}>Saiba mais</Link>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        <section className="py-20">
          <div className="container mx-auto px-4 md:px-6">
            <div className="flex flex-col lg:flex-row gap-12 items-center">
              <div className="w-full lg:w-1/2">
                <div className="relative aspect-[4/3] rounded-lg overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1523438885200-e635ba2c371e?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80"
                    alt="Casal Feliz"
                    className="object-cover w-full h-full"
                  />
                  <div className="absolute inset-0 bg-wedding-purple/10"></div>
                </div>
              </div>
              
              <div className="w-full lg:w-1/2">
                <h2 className="text-3xl md:text-4xl font-display font-semibold mb-4">
                  Nossa História
                </h2>
                <p className="text-muted-foreground mb-6">
                  Quando nos conhecemos, nunca imaginamos que a vida nos reservaria 
                  uma história tão bonita. Após anos de amizade, descobrimos que nosso 
                  amor estava apenas esperando o momento certo para florescer.
                </p>
                <p className="text-muted-foreground mb-6">
                  Agora, estamos prestes a dar o próximo passo em nossa jornada juntos, 
                  e queremos compartilhar esse momento especial com as pessoas que mais amamos.
                </p>
                <Button asChild className="bg-wedding-purple hover:bg-wedding-purple/90">
                  <Link to="/rsvp">Confirmar Presença</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
        
        <section className="py-20 bg-wedding-gradient">
          <div className="container mx-auto px-4 md:px-6 text-center">
            <h2 className="text-3xl md:text-4xl font-display font-semibold mb-6">
              Junte-se a Nós
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              {weddingDate.toLocaleDateString('pt-BR', { 
                day: 'numeric', 
                month: 'long', 
                year: 'numeric' 
              })} às {weddingDate.toLocaleTimeString('pt-BR', { 
                hour: '2-digit', 
                minute: '2-digit' 
              })}
            </p>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              {venue.name}<br />
              {venue.address}
            </p>
            <Button size="lg" asChild className="bg-wedding-purple hover:bg-wedding-purple/90">
              <Link to="/rsvp">
                Confirmar Presença
              </Link>
            </Button>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
