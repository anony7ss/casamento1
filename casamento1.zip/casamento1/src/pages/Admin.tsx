
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useWedding } from "@/contexts/WeddingContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/components/ui/use-toast";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { format } from "date-fns";
import { 
  LogOut, 
  Plus, 
  Trash2, 
  Users, 
  DollarSign, 
  ClipboardList, 
  PieChart, 
  Edit,
  Save,
  ChevronUp,
  ChevronDown,
  Sparkles
} from "lucide-react";
import { 
  PieChart as RechartsPieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip, 
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Area,
  AreaChart,
} from "recharts";

const Admin = () => {
  const { logout, guests, notes, addNote, removeNote, budget, updateExpense, addExpenseCategory, removeExpenseCategory } = useWedding();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Notes state management
  const [newNote, setNewNote] = useState({
    title: "",
    content: "",
  });

  // Expense management states
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editMode, setEditMode] = useState<string | null>(null);
  const [newExpense, setNewExpense] = useState({
    name: "",
    amount: "",
    color: "#9b87f5"
  });
  
  const [editedExpenses, setEditedExpenses] = useState<Record<string, { name: string, amount: string }>>({});
  const [chartAnimation, setChartAnimation] = useState(false);
  
  // Start animation when component mounts
  useEffect(() => {
    setChartAnimation(true);
  }, []);
  
  // Note handlers
  const handleNoteChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewNote((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (newNote.title.trim() === "" || newNote.content.trim() === "") {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha título e conteúdo da nota.",
        variant: "destructive",
      });
      return;
    }
    
    addNote(newNote);
    
    toast({
      title: "Nota adicionada!",
      description: "Sua nota foi adicionada com sucesso.",
    });
    
    setNewNote({
      title: "",
      content: "",
    });
  };
  
  const handleDeleteNote = (id: string) => {
    removeNote(id);
    
    toast({
      title: "Nota removida",
      description: "A nota foi removida com sucesso.",
    });
  };
  
  // Logout handler
  const handleLogout = () => {
    logout();
    navigate("/");
    
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado com sucesso.",
    });
  };

  // Expense handlers
  const handleExpenseInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewExpense(prev => ({
      ...prev,
      [name]: name === 'amount' ? value.replace(/[^0-9]/g, '') : value
    }));
  };

  const handleAddExpense = () => {
    if (!newExpense.name || !newExpense.amount) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha nome e valor da despesa.",
        variant: "destructive",
      });
      return;
    }

    addExpenseCategory({
      name: newExpense.name,
      amount: Number(newExpense.amount),
      color: newExpense.color
    });
    
    setNewExpense({
      name: "",
      amount: "",
      color: "#9b87f5"
    });
    
    setDialogOpen(false);
    
    // Trigger chart animation
    setChartAnimation(false);
    setTimeout(() => setChartAnimation(true), 100);
  };

  const handleEditExpense = (id: string) => {
    const expense = budget.expenses.find(e => e.id === id);
    if (expense) {
      setEditedExpenses({
        ...editedExpenses,
        [id]: { name: expense.name, amount: expense.amount.toString() }
      });
      setEditMode(id);
    }
  };

  const handleEditInputChange = (id: string, field: 'name' | 'amount', value: string) => {
    setEditedExpenses(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        [field]: field === 'amount' ? value.replace(/[^0-9]/g, '') : value
      }
    }));
  };

  const handleSaveEdit = (id: string) => {
    const editedExpense = editedExpenses[id];
    if (!editedExpense.name || !editedExpense.amount) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha nome e valor da despesa.",
        variant: "destructive",
      });
      return;
    }

    updateExpense(id, Number(editedExpense.amount));
    setEditMode(null);
    
    // Trigger chart animation
    setChartAnimation(false);
    setTimeout(() => setChartAnimation(true), 100);
  };

  const handleDeleteExpense = (id: string) => {
    removeExpenseCategory(id);
    
    // Trigger chart animation
    setChartAnimation(false);
    setTimeout(() => setChartAnimation(true), 100);
  };
  
  // Formatting the data for the budget chart
  const budgetData = budget.expenses
    .filter(expense => expense.amount > 0) // Only show expenses with amount > 0
    .map((expense) => ({
      name: expense.name,
      value: expense.amount,
      color: expense.color,
    }));
  
  // Format data for bar chart
  const barData = [...budgetData].sort((a, b) => b.value - a.value);
  
  // Generate some data for the area chart (placeholder for statistics over time)
  const generateTimeData = () => {
    const months = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun"];
    let total = budget.total * 0.5;
    
    return months.map(month => {
      total = total + (total * 0.1);
      return {
        month,
        total: Math.round(total / 1000) * 1000,
      };
    });
  };
  
  const timeData = generateTimeData();
  
  const confirmedGuests = guests.filter((guest) => guest.confirmed);
  const pendingGuests = guests.filter((guest) => !guest.confirmed);
  
  // Custom RADIAN for pie chart labels
  const RADIAN = Math.PI / 180;
  
  // Custom label for pie chart
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);
    
    return (
      <text 
        x={x} 
        y={y} 
        fill="white" 
        textAnchor={x > cx ? 'start' : 'end'} 
        dominantBaseline="central"
        className="text-xs font-medium"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <header className="bg-white shadow-sm border-b border-border/50 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <Sparkles className="h-6 w-6 text-wedding-purple mr-2" />
            <h1 className="text-2xl font-display font-semibold">Painel Administrativo</h1>
          </div>
          <Button variant="outline" onClick={handleLogout} className="transition-all hover:bg-red-50 hover:text-red-600 hover:border-red-200">
            <LogOut className="mr-2 h-4 w-4" />
            Sair
          </Button>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="dashboard" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4 p-1 bg-white border rounded-xl shadow-sm">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-wedding-purple data-[state=active]:text-white rounded-lg">
              <PieChart className="mr-2 h-4 w-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="guests" className="data-[state=active]:bg-wedding-purple data-[state=active]:text-white rounded-lg">
              <Users className="mr-2 h-4 w-4" />
              Convidados
            </TabsTrigger>
            <TabsTrigger value="expenses" className="data-[state=active]:bg-wedding-purple data-[state=active]:text-white rounded-lg">
              <DollarSign className="mr-2 h-4 w-4" />
              Despesas
            </TabsTrigger>
            <TabsTrigger value="notes" className="data-[state=active]:bg-wedding-purple data-[state=active]:text-white rounded-lg">
              <ClipboardList className="mr-2 h-4 w-4" />
              Anotações
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="pb-2 bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                  <CardTitle className="flex items-center text-lg">
                    <Users className="mr-2 h-5 w-5 text-wedding-purple" />
                    Total de Convidados
                  </CardTitle>
                  <CardDescription>Convidados confirmados e pendentes</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="text-3xl font-bold">{guests.length}</div>
                  <div className="flex items-center mt-2 text-sm">
                    <span className="flex items-center text-green-600 mr-4">
                      <ChevronUp className="h-4 w-4 mr-1" /> 
                      {confirmedGuests.length} confirmados
                    </span>
                    <span className="flex items-center text-amber-600">
                      <ChevronDown className="h-4 w-4 mr-1" /> 
                      {pendingGuests.length} pendentes
                    </span>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="pb-2 bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                  <CardTitle className="flex items-center text-lg">
                    <DollarSign className="mr-2 h-5 w-5 text-wedding-purple" />
                    Orçamento Total
                  </CardTitle>
                  <CardDescription>Valor total do orçamento</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="text-3xl font-bold transition-all duration-500 ease-in-out">
                    R$ {budget.total.toLocaleString('pt-BR')}
                  </div>
                  <div className="flex items-center mt-2 text-sm">
                    <span className="text-purple-600">
                      {budget.expenses.filter(e => e.amount > 0).length} categorias
                    </span>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="pb-2 bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                  <CardTitle className="flex items-center text-lg">
                    <ClipboardList className="mr-2 h-5 w-5 text-wedding-purple" />
                    Anotações
                  </CardTitle>
                  <CardDescription>Total de anotações salvas</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="text-3xl font-bold">{notes.length}</div>
                  <div className="mt-2 text-sm text-muted-foreground">
                    Clique na aba "Anotações" para gerenciar
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                  <CardTitle className="flex items-center">
                    <PieChart className="mr-2 h-5 w-5 text-wedding-purple" />
                    Distribuição do Orçamento
                  </CardTitle>
                  <CardDescription>
                    Visualização da distribuição do orçamento por categoria
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="h-[300px]">
                    {chartAnimation && (
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPieChart>
                          <Pie
                            data={budgetData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={renderCustomizedLabel}
                            outerRadius={110}
                            fill="#8884d8"
                            dataKey="value"
                            nameKey="name"
                            animationBegin={0}
                            animationDuration={1200}
                            className="drop-shadow-lg"
                          >
                            {budgetData.map((entry, index) => (
                              <Cell 
                                key={`cell-${index}`} 
                                fill={entry.color} 
                                className="drop-shadow-md hover:opacity-80 transition-opacity" 
                              />
                            ))}
                          </Pie>
                          <Tooltip 
                            formatter={(value) => `R$ ${Number(value).toLocaleString('pt-BR')}`} 
                            contentStyle={{ 
                              borderRadius: '8px', 
                              border: 'none',
                              boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)'
                            }}
                          />
                          <Legend 
                            layout="vertical" 
                            verticalAlign="middle" 
                            align="right"
                            wrapperStyle={{ fontSize: '12px' }}
                          />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                  <CardTitle className="flex items-center">
                    <Users className="mr-2 h-5 w-5 text-wedding-purple" />
                    Convidados Recentes
                  </CardTitle>
                  <CardDescription>
                    Últimas confirmações de presença
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4">
                  {guests.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-[300px] bg-gray-50 rounded-lg border border-dashed border-gray-200">
                      <Users className="h-12 w-12 text-gray-300 mb-4" />
                      <p className="text-muted-foreground text-center">
                        Nenhum convidado registrado ainda.<br />
                        Os convidados aparecerão aqui quando confirmarem presença.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
                      {guests.slice(0, 5).map((guest) => (
                        <div key={guest.id} className="flex items-start justify-between p-4 border border-gray-100 rounded-lg bg-white shadow-sm hover:shadow-md transition-shadow">
                          <div>
                            <h3 className="font-medium">{guest.name}</h3>
                            <div className="flex items-center mt-1">
                              <span className={`px-2 py-0.5 rounded-full text-xs ${
                                guest.confirmed 
                                  ? "bg-green-100 text-green-800" 
                                  : "bg-yellow-100 text-yellow-800"
                              }`}>
                                {guest.confirmed ? "Confirmado" : "Não confirmado"}
                              </span>
                              <span className="ml-2 text-sm text-muted-foreground">
                                {guest.numberOfGuests} {guest.numberOfGuests > 1 ? "pessoas" : "pessoa"}
                              </span>
                            </div>
                          </div>
                          <div className="text-sm text-muted-foreground bg-gray-50 px-2 py-1 rounded">
                            {format(new Date(guest.timestamp), "dd/MM/yyyy")}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 gap-6">
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                  <CardTitle className="flex items-center">
                    <DollarSign className="mr-2 h-5 w-5 text-wedding-purple" />
                    Maiores Despesas
                  </CardTitle>
                  <CardDescription>
                    Ranking das maiores despesas do casamento
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="h-[300px]">
                    {chartAnimation && (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={barData} layout="vertical" margin={{ left: 100, right: 30 }}>
                          <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                          <XAxis type="number" tickFormatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
                          <YAxis 
                            type="category" 
                            dataKey="name" 
                            width={90}
                            tickLine={false}
                          />
                          <Tooltip 
                            formatter={(value) => `R$ ${Number(value).toLocaleString('pt-BR')}`}
                            contentStyle={{ 
                              borderRadius: '8px', 
                              border: 'none',
                              boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)'
                            }}
                          />
                          <Bar 
                            dataKey="value" 
                            animationBegin={0}
                            animationDuration={1200}
                            radius={[0, 4, 4, 0]}
                          >
                            {barData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="guests">
            <Card className="overflow-hidden transition-all hover:shadow-md">
              <CardHeader className="bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-5 w-5 text-wedding-purple" />
                  Lista de Convidados
                </CardTitle>
                <CardDescription>
                  Gerencie os convidados do seu casamento
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4">
                {guests.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-200">
                    <Users className="h-12 w-12 text-gray-300 mb-4" />
                    <p className="text-muted-foreground text-center">
                      Nenhum convidado registrado ainda.<br />
                      Os convidados aparecerão aqui quando confirmarem presença.
                    </p>
                  </div>
                ) : (
                  <div className="rounded-lg border shadow-sm overflow-hidden">
                    <Table>
                      <TableHeader className="bg-muted/30">
                        <TableRow>
                          <TableHead>Nome</TableHead>
                          <TableHead>Contato</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Convidados</TableHead>
                          <TableHead>Data</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {guests.map((guest) => (
                          <TableRow key={guest.id} className="hover:bg-muted/30 transition-colors">
                            <TableCell className="font-medium">{guest.name}</TableCell>
                            <TableCell>
                              <div>{guest.email}</div>
                              <div className="text-muted-foreground text-sm">{guest.phone}</div>
                            </TableCell>
                            <TableCell>
                              <span className={`px-2 py-1 rounded-full text-xs ${
                                guest.confirmed 
                                  ? "bg-green-100 text-green-800" 
                                  : "bg-yellow-100 text-yellow-800"
                              }`}>
                                {guest.confirmed ? "Confirmado" : "Não confirmado"}
                              </span>
                            </TableCell>
                            <TableCell>{guest.numberOfGuests}</TableCell>
                            <TableCell>{format(new Date(guest.timestamp), "dd/MM/yyyy")}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="expenses" className="space-y-6">
            <Card className="overflow-hidden transition-all hover:shadow-md">
              <CardHeader className="flex flex-row items-center justify-between bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                <div>
                  <CardTitle className="flex items-center">
                    <DollarSign className="mr-2 h-5 w-5 text-wedding-purple" />
                    Gerenciar Despesas
                  </CardTitle>
                  <CardDescription>
                    Adicione, edite e remova despesas do seu casamento
                  </CardDescription>
                </div>
                <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-wedding-purple hover:bg-wedding-purple/90 transition-colors">
                      <Plus className="mr-2 h-4 w-4" />
                      Nova Despesa
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Adicionar Nova Despesa</DialogTitle>
                      <DialogDescription>
                        Preencha os detalhes da nova despesa abaixo.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <label htmlFor="name" className="text-sm font-medium">
                          Nome da Categoria
                        </label>
                        <Input
                          id="name"
                          name="name"
                          value={newExpense.name}
                          onChange={handleExpenseInputChange}
                          placeholder="Ex: Decoração, Buffet, etc."
                          className="focus-within:ring-wedding-purple"
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="amount" className="text-sm font-medium">
                          Valor (R$)
                        </label>
                        <Input
                          id="amount"
                          name="amount"
                          value={newExpense.amount}
                          onChange={handleExpenseInputChange}
                          placeholder="0"
                          className="focus-within:ring-wedding-purple"
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="color" className="text-sm font-medium">
                          Cor
                        </label>
                        <div className="flex items-center space-x-2">
                          <Input
                            type="color"
                            id="color"
                            name="color"
                            value={newExpense.color}
                            onChange={handleExpenseInputChange}
                            className="w-20 h-10 p-1 cursor-pointer"
                          />
                          <span className="text-sm text-muted-foreground">
                            Cor para representar esta categoria no gráfico
                          </span>
                        </div>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setDialogOpen(false)}>
                        Cancelar
                      </Button>
                      <Button onClick={handleAddExpense} className="bg-wedding-purple hover:bg-wedding-purple/90">
                        Adicionar Despesa
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent className="p-4">
                {budget.expenses.filter(e => e.amount > 0).length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-200">
                    <DollarSign className="h-12 w-12 text-gray-300 mb-4" />
                    <p className="text-muted-foreground text-center">
                      Nenhuma despesa registrada ainda.<br />
                      Clique em "Nova Despesa" para adicionar.
                    </p>
                  </div>
                ) : (
                  <div className="rounded-lg border shadow-sm overflow-hidden">
                    <Table>
                      <TableHeader className="bg-muted/30">
                        <TableRow>
                          <TableHead>Categoria</TableHead>
                          <TableHead>Valor</TableHead>
                          <TableHead>Cor</TableHead>
                          <TableHead className="text-right">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {budget.expenses
                          .filter(expense => expense.amount > 0)
                          .map((expense) => (
                            <TableRow key={expense.id} className="hover:bg-muted/30 transition-colors">
                              <TableCell>
                                {editMode === expense.id ? (
                                  <Input
                                    value={editedExpenses[expense.id]?.name || expense.name}
                                    onChange={(e) => handleEditInputChange(expense.id, 'name', e.target.value)}
                                    className="w-full focus-within:ring-wedding-purple"
                                  />
                                ) : (
                                  <div className="font-medium">{expense.name}</div>
                                )}
                              </TableCell>
                              <TableCell>
                                {editMode === expense.id ? (
                                  <Input
                                    value={editedExpenses[expense.id]?.amount || expense.amount.toString()}
                                    onChange={(e) => handleEditInputChange(expense.id, 'amount', e.target.value)}
                                    className="w-full focus-within:ring-wedding-purple"
                                  />
                                ) : (
                                  <div className="font-medium">R$ {expense.amount.toLocaleString('pt-BR')}</div>
                                )}
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center space-x-2">
                                  <div 
                                    className="w-6 h-6 rounded-full" 
                                    style={{ backgroundColor: expense.color }}
                                  />
                                </div>
                              </TableCell>
                              <TableCell className="text-right">
                                {editMode === expense.id ? (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleSaveEdit(expense.id)}
                                    className="mr-2 border-green-200 hover:bg-green-50 hover:text-green-600 hover:border-green-300 transition-colors"
                                  >
                                    <Save className="h-4 w-4 mr-1" />
                                    Salvar
                                  </Button>
                                ) : (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleEditExpense(expense.id)}
                                    className="mr-2 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition-colors"
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                )}
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleDeleteExpense(expense.id)}
                                  className="hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-colors"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                  <CardTitle className="flex items-center">
                    <PieChart className="mr-2 h-5 w-5 text-wedding-purple" />
                    Distribuição do Orçamento
                  </CardTitle>
                  <CardDescription>
                    Visualização das despesas em gráfico de pizza
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="bg-white p-6 rounded-lg">
                    <div className="text-3xl font-bold mb-2">R$ {budget.total.toLocaleString('pt-BR')}</div>
                    <p className="text-sm text-muted-foreground mb-6">Orçamento total do casamento</p>
                    
                    <div className="h-[280px]">
                      {chartAnimation && (
                        <ResponsiveContainer width="100%" height="100%">
                          <RechartsPieChart>
                            <Pie
                              data={budgetData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              label={renderCustomizedLabel}
                              outerRadius={120}
                              innerRadius={60}
                              fill="#8884d8"
                              dataKey="value"
                              nameKey="name"
                              animationBegin={0}
                              animationDuration={1200}
                              className="drop-shadow-lg"
                            >
                              {budgetData.map((entry, index) => (
                                <Cell 
                                  key={`cell-${index}`} 
                                  fill={entry.color} 
                                  className="drop-shadow-md hover:opacity-80 transition-opacity" 
                                />
                              ))}
                            </Pie>
                            <Tooltip 
                              formatter={(value) => `R$ ${Number(value).toLocaleString('pt-BR')}`} 
                              contentStyle={{ 
                                borderRadius: '8px', 
                                border: 'none',
                                boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)'
                              }}
                            />
                            <Legend 
                              layout="vertical" 
                              verticalAlign="middle" 
                              align="right"
                              wrapperStyle={{ fontSize: '12px' }}
                            />
                          </RechartsPieChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                  <CardTitle className="flex items-center">
                    <DollarSign className="mr-2 h-5 w-5 text-wedding-purple" />
                    Projeção de Gastos
                  </CardTitle>
                  <CardDescription>
                    Evolução estimada dos gastos
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="h-[340px]">
                    {chartAnimation && (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={timeData}
                          margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis tickFormatter={(value) => `R$ ${value/1000}k`} />
                          <Tooltip 
                            formatter={(value) => `R$ ${Number(value).toLocaleString('pt-BR')}`}
                            contentStyle={{ 
                              borderRadius: '8px', 
                              border: 'none',
                              boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)'
                            }}
                          />
                          <Area 
                            type="monotone" 
                            dataKey="total" 
                            stroke="#9b87f5" 
                            fill="url(#colorGradient)" 
                            animationBegin={0}
                            animationDuration={1500}
                          />
                          <defs>
                            <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#9b87f5" stopOpacity={0.8}/>
                              <stop offset="95%" stopColor="#9b87f5" stopOpacity={0.1}/>
                            </linearGradient>
                          </defs>
                        </AreaChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="notes" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-1">
                <Card className="overflow-hidden transition-all hover:shadow-md">
                  <CardHeader className="bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                    <CardTitle className="flex items-center">
                      <ClipboardList className="mr-2 h-5 w-5 text-wedding-purple" />
                      Adicionar Nota
                    </CardTitle>
                    <CardDescription>
                      Adicione notas e lembretes para o casamento
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-4">
                    <form onSubmit={handleAddNote} className="space-y-4">
                      <div className="space-y-2">
                        <label htmlFor="title" className="text-sm font-medium">
                          Título
                        </label>
                        <Input
                          id="title"
                          name="title"
                          value={newNote.title}
                          onChange={handleNoteChange}
                          placeholder="Título da nota"
                          className="focus-within:ring-wedding-purple"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="content" className="text-sm font-medium">
                          Conteúdo
                        </label>
                        <Textarea
                          id="content"
                          name="content"
                          value={newNote.content}
                          onChange={handleNoteChange}
                          placeholder="Conteúdo da nota"
                          rows={5}
                          className="resize-none focus-within:ring-wedding-purple"
                          required
                        />
                      </div>
                      <Button type="submit" className="w-full bg-wedding-purple hover:bg-wedding-purple/90 transition-colors">
                        <Plus className="mr-2 h-4 w-4" />
                        Adicionar Nota
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>
              
              <div className="md:col-span-2">
                <Card className="overflow-hidden transition-all hover:shadow-md">
                  <CardHeader className="bg-gradient-to-r from-wedding-purple/10 to-wedding-purple/5">
                    <CardTitle className="flex items-center">
                      <ClipboardList className="mr-2 h-5 w-5 text-wedding-purple" />
                      Minhas Notas
                    </CardTitle>
                    <CardDescription>
                      Gerencie suas notas e lembretes
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-4">
                    {notes.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-200">
                        <ClipboardList className="h-12 w-12 text-gray-300 mb-4" />
                        <p className="text-muted-foreground text-center">
                          Nenhuma nota adicionada ainda.<br />
                          Use o formulário ao lado para adicionar notas.
                        </p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {notes.map((note) => (
                          <div 
                            key={note.id} 
                            className="border border-gray-100 rounded-lg p-4 relative bg-white shadow-sm hover:shadow-md transition-shadow"
                          >
                            <Button
                              variant="ghost"
                              size="icon"
                              className="absolute top-2 right-2 text-muted-foreground hover:text-red-500 hover:bg-red-50 transition-colors"
                              onClick={() => handleDeleteNote(note.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                            <h3 className="font-semibold text-lg mb-2 pr-8">{note.title}</h3>
                            <p className="text-muted-foreground mb-3">{note.content}</p>
                            <div className="text-xs text-muted-foreground pt-2 border-t border-gray-100">
                              {format(new Date(note.timestamp), "dd/MM/yyyy 'às' HH:mm")}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Admin;
