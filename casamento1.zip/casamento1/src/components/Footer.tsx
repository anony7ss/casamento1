
import { Heart } from "lucide-react";
import { useWedding } from "@/contexts/WeddingContext";

const Footer = () => {
  const { brideAndGroom } = useWedding();
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-10 border-t border-border/50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col items-center justify-center gap-4 md:flex-row md:justify-between">
          <div className="flex items-center gap-2 font-display text-lg">
            <Heart className="text-wedding-purple h-4 w-4 fill-wedding-purple" />
            <span>{brideAndGroom.bride}</span>
            <span className="text-wedding-purple">&</span>
            <span>{brideAndGroom.groom}</span>
          </div>
          
          <div className="text-sm text-muted-foreground">
            © {currentYear} Todos os direitos reservados
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
