
import { Navigate } from "react-router-dom";
import { useWedding } from "@/contexts/WeddingContext";

const AdminRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAdmin, loading } = useWedding();
  
  // Show loading state if we're still checking admin status
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-wedding-gradient">
        <div className="text-center bg-white p-8 rounded-xl shadow-lg">
          <div className="inline-block animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-wedding-purple"></div>
          <p className="mt-4 text-wedding-purple font-medium">Verificando acesso...</p>
        </div>
      </div>
    );
  }
  
  // If not admin, redirect to login page
  if (!isAdmin) {
    return <Navigate to="/login" replace />;
  }
  
  // If admin, render the children
  return <>{children}</>;
};

export default AdminRoute;
