
import { useState, useEffect } from "react";
import { useWedding } from "@/contexts/WeddingContext";

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

const CountdownTimer = () => {
  const { weddingDate } = useWedding();
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });
  
  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = +weddingDate - +new Date();
      
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        });
      } else {
        setTimeLeft({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
        });
      }
    };
    
    calculateTimeLeft();
    const timer = setInterval(() => {
      calculateTimeLeft();
    }, 1000);
    
    return () => clearInterval(timer);
  }, [weddingDate]);
  
  return (
    <div className="w-full bg-white/80 backdrop-blur-sm rounded-lg shadow-md p-6 border border-wedding-lavender/30 animate-float">
      <h2 className="text-2xl md:text-3xl font-display text-center mb-6">Contagem Regressiva</h2>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 md:w-20 md:h-20 bg-wedding-purple/10 rounded-full flex items-center justify-center mb-2 border border-wedding-purple/20">
            <span className="text-2xl md:text-3xl font-semibold text-wedding-purple">{timeLeft.days}</span>
          </div>
          <span className="text-sm md:text-base text-muted-foreground">Dias</span>
        </div>
        
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 md:w-20 md:h-20 bg-wedding-lavender/20 rounded-full flex items-center justify-center mb-2 border border-wedding-lavender/30">
            <span className="text-2xl md:text-3xl font-semibold text-wedding-purple">{timeLeft.hours}</span>
          </div>
          <span className="text-sm md:text-base text-muted-foreground">Horas</span>
        </div>
        
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 md:w-20 md:h-20 bg-wedding-rose/20 rounded-full flex items-center justify-center mb-2 border border-wedding-rose/30">
            <span className="text-2xl md:text-3xl font-semibold text-wedding-purple">{timeLeft.minutes}</span>
          </div>
          <span className="text-sm md:text-base text-muted-foreground">Minutos</span>
        </div>
        
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 md:w-20 md:h-20 bg-wedding-gold/10 rounded-full flex items-center justify-center mb-2 border border-wedding-gold/20">
            <span className="text-2xl md:text-3xl font-semibold text-wedding-purple">{timeLeft.seconds}</span>
          </div>
          <span className="text-sm md:text-base text-muted-foreground">Segundos</span>
        </div>
      </div>
    </div>
  );
};

export default CountdownTimer;
