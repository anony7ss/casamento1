
import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Heart } from "lucide-react";
import { useWedding } from "@/contexts/WeddingContext";
import { cn } from "@/lib/utils";

const Navbar = () => {
  const { brideAndGroom, isAdmin } = useWedding();
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { name: "Início", path: "/" },
    { name: "RSVP", path: "/rsvp" },
    { name: "Galeria", path: "/gallery" },
    { name: "Informações", path: "/info" },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed w-full bg-background/80 backdrop-blur-sm z-50 py-4 border-b border-border/50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          <Link 
            to="/"
            className="flex items-center gap-2 font-display text-2xl hover-lift"
          >
            <Heart className="text-wedding-purple h-5 w-5" />
            <span className="hidden md:inline-block">{brideAndGroom.bride}</span>
            <span className="text-wedding-purple inline-block mx-1">&</span>
            <span className="hidden md:inline-block">{brideAndGroom.groom}</span>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "hover-lift font-medium",
                  isActive(item.path)
                    ? "text-primary"
                    : "text-foreground/70 hover:text-foreground"
                )}
              >
                {item.name}
              </Link>
            ))}
            
            {isAdmin && (
              <Link
                to="/admin"
                className={cn(
                  "hover-lift font-medium",
                  isActive("/admin")
                    ? "text-primary"
                    : "text-foreground/70 hover:text-foreground"
                )}
              >
                Admin
              </Link>
            )}
            
            {!isAdmin && (
              <Link
                to="/login"
                className="text-foreground/70 hover:text-foreground hover-lift font-medium"
              >
                Login
              </Link>
            )}
          </div>
          
          {/* Mobile Hamburger */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-foreground p-2"
            >
              {isOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-background border-b border-border/50 shadow-md animate-fade-in">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className={cn(
                  "py-2 font-medium",
                  isActive(item.path)
                    ? "text-primary"
                    : "text-foreground/70"
                )}
              >
                {item.name}
              </Link>
            ))}
            
            {isAdmin && (
              <Link
                to="/admin"
                onClick={() => setIsOpen(false)}
                className={cn(
                  "py-2 font-medium",
                  isActive("/admin")
                    ? "text-primary"
                    : "text-foreground/70"
                )}
              >
                Admin
              </Link>
            )}
            
            {!isAdmin && (
              <Link
                to="/login"
                onClick={() => setIsOpen(false)}
                className="py-2 font-medium text-foreground/70"
              >
                Login
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
