
import { useWedding } from "@/contexts/WeddingContext";
import { ArrowRight, Heart } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import CountdownTimer from "./CountdownTimer";

const HeroSection = () => {
  const { brideAndGroom, weddingDate, venue } = useWedding();
  
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center py-24 px-4">
      <div 
        className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1519741497674-611481863552?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80')] bg-cover bg-center opacity-10"
        aria-hidden="true"
      />
      
      <div className="container max-w-5xl mx-auto z-10 space-y-8">
        <div className="text-center space-y-3 animate-fade-in">
          <p className="text-muted-foreground uppercase tracking-wide font-medium">
            Convidamos você para celebrar nosso casamento
          </p>
          
          <h1 className="text-4xl md:text-6xl font-display font-semibold text-foreground">
            {brideAndGroom.bride} <Heart className="inline h-8 w-8 mx-2 text-wedding-purple fill-wedding-purple animate-pulse-soft" /> {brideAndGroom.groom}
          </h1>
          
          <p className="mt-4 text-lg md:text-xl text-muted-foreground">
            {weddingDate.toLocaleDateString('pt-BR', { 
              day: 'numeric', 
              month: 'long', 
              year: 'numeric' 
            })}
          </p>
          
          <p className="text-md md:text-lg text-muted-foreground">
            {venue.name} - {venue.address}
          </p>
        </div>
        
        <div className="mt-8 flex justify-center">
          <CountdownTimer />
        </div>
        
        <div className="mt-8 flex flex-col md:flex-row gap-4 justify-center">
          <Button size="lg" asChild className="bg-wedding-purple hover:bg-wedding-purple/90">
            <Link to="/rsvp">
              Confirmar Presença
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          
          <Button size="lg" variant="outline" asChild>
            <Link to="/info">Ver Programação</Link>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
